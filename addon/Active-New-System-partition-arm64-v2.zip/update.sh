#!/sbin/sh



# Example:


# ui_print "Applying update..."
#
# package_extract_file newbinary $INSTALLDIR/newbinary
#
# mv $INSTALLDIR/newbinary /system/bin/newbinary
#
# set_metadata /system/bin/newbinary uid root gid shell mode 755
#
# 
# ui_print "Update successfully installed!"
ui_print "";
ui_print "";
ui_print "#########################################";
ui_print "#                                       #";
ui_print "#       Active-New-System-partition     #"; 
ui_print "#                                       #";
ui_print "#                                       #";
ui_print "#            by Abdelhay Ali            #";
ui_print "#                                       #";
ui_print "#                                       #";
ui_print "#                 V2.0                  #";
ui_print "#                                       #";
ui_print "#########################################";
ui_print "";
ui_print "";




#abort if any error occurred 
set -e


ui_print "move parted to sbin folder";
mv $INSTALLDIR/parted /sbin/parted
chmod 777 /sbin/parted

#get partition table
OUTPUT=$(parted -s /dev/block/mmcblk0 unit GB print)
#ui_print "${OUTPUT}"


# get the number of current active system partition
search="         system "
prefix=${OUTPUT%%$search*}
System_number=${OUTPUT:${#prefix}-36:2}
ui_print "Current System partition number is: ${System_number}"
sleep 1

# get the number of system-b partition
search="         system-b"
prefix=${OUTPUT%%$search*}
System_b_number=${OUTPUT:${#prefix}-36:2}
ui_print "Current System_b partition number is: ${System_b_number}"

#exit if OUTPUT, System_number or System_b_number are null
if [ -z "$OUTPUT" ] || [ -z "$System_b_number" ] || [ -z "$System_number" ]; then 
    ui_print "An error occurred. Exiting..." 
    exit 1
fi

# active new System
if (( System_number > System_b_number )); then
    ui_print "new System already activated"
else
   ui_print "swap partition numbers"
    parted -s /dev/block/mmcblk0 name ${System_b_number} system
    ui_print "set partition number ${System_b_number} as system (active) "
	sleep 1
	parted -s /dev/block/mmcblk0 name ${System_number} system-b
	ui_print "set partition number ${System_number} as system-b"
	ui_print "please reboot before make any other changes"
	sleep 3
fi
ui_print "Update successfully installed!"
exit 0;