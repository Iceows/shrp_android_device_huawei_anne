#!/sbin/sh



# Example:

# ui_print "Applying update..."
#
# package_extract_file newbinary $INSTALLDIR/newbinary
#
# mv $INSTALLDIR/newbinary /system/bin/newbinary
#
# set_metadata /system/bin/newbinary uid root gid shell mode 755
#
# 
# ui_print "Update successfully installed!"
ui_print "";
ui_print "";
ui_print "#########################################";
ui_print "#                                       #";
ui_print "#     Active-Default-userdata profile   #"; 
ui_print "#                                       #";
ui_print "#                                       #";
ui_print "#            by Abdelhay Ali            #";
ui_print "#                                       #";
ui_print "#                                       #";
ui_print "#                 V2.0                  #";
ui_print "#                                       #";
ui_print "#########################################";
ui_print "";
ui_print "";




#abort if any error occurred 
#set -e
ui_print "change fstab.hi6250 file";
mv $INSTALLDIR/fstab.hi6250 /vendor/etc/fstab.hi6250


ui_print "create the new userdata profile in data/profile2";
    mkdir /data/profile2 || true
    #mkdir /data/profile2/a || true
    mkdir /vendor/userdata || true

# Prepare media 	
	mkdir /data/profile2/media;
	mkdir /data/profile2/media/0;

      ui_print "Update successfully installed!"
exit 0;